﻿namespace CustomerCRUDApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class v1_initial_migration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(),
                        DateOfBirth = c.DateTime(nullable: false),
                        Location = c.String(),
                        City = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Customers");
        }
    }
}
